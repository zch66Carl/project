Seng201 project by Nicholas Grace and Carl Chen

The source code and compiled java doc are within the project folder.
All uml is in the uml folder.

Importing the project into eclipse:
From eclipse, navigate to file > open projects from file system.
Set the import source directory to the project folder.
Click finish.

The entry point of the GUI application is /src/GUI/SetupScreen.java
The entry point of the CLI application is /src/commandline/Start.java

Running the JAR file:
Ensure Java 17 is installed on the machine.
Open the zip folder in a temrinal window.
Run "java -jar ngr55_zch66_MonsterFighter.jar"
