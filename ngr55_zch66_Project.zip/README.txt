Seng201 project by Nicholas Grace and Carl Chen

The source code and compiled java doc are within the project folder.
All uml is in the uml folder.

Importing the project into eclipse:
1 - From eclipse, navigate to file > open projects from file system.
2 - Set the import source directory to the project folder, make sure there is not allready a project called project open in your eclipse workspace.
3 - Click finish.

The entry point of the GUI application is /src/GUI/SetupScreen.java
The entry point of the CLI application is /src/commandline/Start.java

Running the JAR file:
1 - Ensure Java 17 is installed on the machine.
2 - Open the zip folder in a terminal window.
3 - Run "java -jar ngr55_zch66_MonsterFighter.jar"
